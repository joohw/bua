// src/popup.ts
void function main() {
  const $ = (id) => {
    const el = document.getElementById(id);
    if (el === null) throw new Error(`\u7F3A\u5C11\u5143\u7D20 #${id}`);
    return el;
  };
  const dot = $("dot");
  const conn = $("conn");
  const meta = $("meta");
  const caps = $("caps");
  const warn = $("warn");
  const empty = $("empty");
  const logList = $("log");
  const clearBtn = $("clear");
  const settingsBtn = $("openOnboarding");
  const reconnectBtn = $("reconnect");
  const CAP_LABELS = {
    cdp: "CDP",
    screenshots: "\u622A\u56FE",
    fileUploads: "\u4E0A\u4F20",
    downloads: "\u4E0B\u8F7D",
    evaluate: "\u6267\u884C JS",
    management: "\u6D4F\u89C8\u5668\u7BA1\u7406"
  };
  function fmtTime(ts) {
    const d = new Date(ts);
    const p = (n) => String(n).padStart(2, "0");
    return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
  }
  function renderCaps(capabilities) {
    caps.textContent = "";
    for (const [key, value] of Object.entries(capabilities)) {
      if (key === "notes") continue;
      const el = document.createElement("span");
      el.className = `cap ${value === true ? "on" : "off"}`;
      el.textContent = CAP_LABELS[key] ?? key;
      caps.appendChild(el);
    }
  }
  function renderLog(entries) {
    logList.textContent = "";
    if (entries.length === 0) {
      empty.style.display = "block";
      return;
    }
    empty.style.display = "none";
    for (const e of entries) {
      const li = document.createElement("li");
      const time = document.createElement("span");
      time.className = "time";
      time.textContent = fmtTime(e.ts);
      const body = document.createElement("div");
      body.className = "body";
      const m = document.createElement("div");
      m.className = `m${e.ok ? "" : " fail"}`;
      m.textContent = e.method + (e.errorCode !== void 0 ? ` \u2192 ${e.errorCode}` : "");
      body.appendChild(m);
      if (e.targetDescription !== void 0) {
        const desc = document.createElement("div");
        desc.className = "desc";
        desc.textContent = e.targetDescription;
        body.appendChild(desc);
      }
      li.append(time, body);
      logList.appendChild(li);
    }
  }
  function render(res) {
    dot.className = `dot ${res.connected ? "on" : "off"}`;
    if (!res.consentGiven) {
      conn.textContent = "\u5C1A\u672A\u542F\u7528";
    } else {
      conn.textContent = res.connected ? "\u5DF2\u8FDE\u63A5\u672C\u5730\u6865" : "\u672A\u8FDE\u63A5\u5230\u6865";
    }
    const attached = res.attachedTabs.length;
    meta.textContent = `ws://127.0.0.1:${res.port}${attached > 0 ? ` \xB7 \u5DF2\u63A5\u7BA1 ${attached} \u4E2A\u6807\u7B7E` : ""}`;
    renderCaps(res.capabilities ?? {});
    const notes = res.capabilities?.notes;
    if (Array.isArray(notes) && notes.length > 0) {
      warn.style.display = "block";
      warn.textContent = notes.join("\uFF1B");
    } else {
      warn.style.display = "none";
    }
    renderLog(res.log ?? []);
  }
  function refresh() {
    chrome.runtime.sendMessage({ type: "bua:status" }, (res) => {
      if (chrome.runtime.lastError || res === void 0) {
        conn.textContent = "\u65E0\u6CD5\u8BFB\u53D6\u72B6\u6001";
        dot.className = "dot off";
        meta.textContent = chrome.runtime.lastError?.message ?? "";
        return;
      }
      render(res);
    });
  }
  refresh();
  chrome.runtime.onMessage.addListener((msg) => {
    if (typeof msg === "object" && msg !== null && msg["type"] === "bua:log") {
      refresh();
    }
    return false;
  });
  clearBtn.addEventListener("click", () => {
    void chrome.storage.local.set({ activityLog: [] }).then(refresh);
  });
  settingsBtn.addEventListener("click", () => {
    void chrome.runtime.openOptionsPage();
  });
}();
