// src/onboarding.ts
void function main() {
  const CONSENT_KEY = "onboardingAcceptedAt";
  const $ = (id) => {
    const el = document.getElementById(id);
    if (el === null) throw new Error(`\u7F3A\u5C11\u5143\u7D20 #${id}`);
    return el;
  };
  const agree = $("agree");
  const enableBtn = $("enable");
  const statusEl = $("status");
  function setStatus(text, kind = "") {
    statusEl.textContent = text;
    statusEl.className = `status ${kind}`.trim();
  }
  function showTutorial() {
    $("disclosure").hidden = true;
    $("tutorial").hidden = false;
    document.title = "BUA \u2014 \u4F7F\u7528\u6559\u7A0B";
    $("pageTitle").textContent = "\u5F00\u59CB\u4F7F\u7528 BUA";
    setStatus("");
  }
  async function load() {
    const match = /\bChrome\/([\d.]+)/.exec(navigator.userAgent);
    $("chromeVersion").textContent = match?.[1] ?? "\u672A\u77E5";
    try {
      const bag = await chrome.storage.local.get(CONSENT_KEY);
      if (typeof bag[CONSENT_KEY] === "number") showTutorial();
    } catch {
      setStatus("\u65E0\u6CD5\u8BFB\u53D6\u542F\u7528\u72B6\u6001\uFF0C\u8BF7\u91CD\u65B0\u6253\u5F00\u9875\u9762\u3002", "err");
    }
  }
  agree.addEventListener("change", () => {
    enableBtn.disabled = !agree.checked;
  });
  enableBtn.addEventListener("click", () => {
    void (async () => {
      if (!agree.checked) {
        setStatus("\u8BF7\u5148\u52FE\u9009\u540C\u610F", "err");
        return;
      }
      enableBtn.disabled = true;
      try {
        const existing = await chrome.storage.local.get(CONSENT_KEY);
        if (typeof existing[CONSENT_KEY] !== "number") {
          await chrome.storage.local.set({ [CONSENT_KEY]: Date.now() });
        }
        showTutorial();
        window.scrollTo(0, 0);
      } catch {
        setStatus("\u542F\u7528\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002", "err");
      } finally {
        enableBtn.disabled = !agree.checked;
      }
    })();
  });
  void load();
}();
