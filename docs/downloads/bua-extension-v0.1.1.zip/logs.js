// src/logs.ts
void function main() {
  const get = (id) => document.getElementById(id);
  const select = get("page");
  const picker = get("picker");
  const pages = get("pages");
  let selectedId = "";
  const list = get("log");
  const state = get("state");
  const retry = get("retry");
  const updates = get("updates");
  let tabs = [];
  let cursor = null;
  let more = true;
  let busy = false;
  let generation = 0;
  const selected = () => tabs.find((tab) => String(tab.id) === selectedId);
  function pageContent(tab) {
    const fragment = document.createDocumentFragment();
    const icon = document.createElement("span");
    icon.className = "favicon";
    icon.setAttribute("aria-hidden", "true");
    icon.textContent = "\u25CE";
    if (tab.favIconUrl && /^(https?:|data:image\/)/i.test(tab.favIconUrl)) {
      const img = document.createElement("img");
      img.alt = "";
      img.referrerPolicy = "no-referrer";
      img.addEventListener("error", () => img.remove());
      img.src = tab.favIconUrl;
      icon.append(img);
    }
    const text = document.createElement("span");
    text.className = "page-text";
    text.textContent = `${tab.title || tab.url} \u2014 ${tab.url}`;
    fragment.append(icon, text);
    return fragment;
  }
  function closePicker(focus = false) {
    pages.hidden = true;
    select.setAttribute("aria-expanded", "false");
    if (focus) select.focus();
  }
  function renderPicker() {
    pages.textContent = "";
    select.disabled = tabs.length === 0;
    const tab = selected();
    select.replaceChildren(tab ? pageContent(tab) : document.createTextNode("\u6682\u65E0\u53EF\u67E5\u770B\u7684\u9875\u9762"));
    select.title = tab ? `${tab.title || ""} \u2014 ${tab.url}` : "";
    for (const item of tabs) {
      const option = document.createElement("button");
      option.type = "button";
      option.setAttribute("role", "option");
      option.setAttribute("aria-selected", String(item.id === tab?.id));
      option.tabIndex = -1;
      option.title = `${item.title || ""} \u2014 ${item.url}`;
      option.append(pageContent(item));
      option.addEventListener("click", () => {
        selectedId = String(item.id);
        closePicker(true);
        renderPicker();
        reset();
      });
      pages.append(option);
    }
  }
  function openPicker(last = false) {
    if (!tabs.length) return;
    pages.hidden = false;
    select.setAttribute("aria-expanded", "true");
    const options = Array.from(pages.querySelectorAll('[role="option"]'));
    (last ? options.at(-1) : options.find((option) => option.getAttribute("aria-selected") === "true") ?? options[0])?.focus();
  }
  select.addEventListener("click", () => pages.hidden ? openPicker() : closePicker());
  select.addEventListener("keydown", (event) => {
    if (event.key === "ArrowDown" || event.key === "ArrowUp") {
      event.preventDefault();
      openPicker(event.key === "ArrowUp");
    }
  });
  picker.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      event.preventDefault();
      closePicker(true);
    }
    if (event.key === "Tab") closePicker();
    if (pages.hidden || !["ArrowDown", "ArrowUp", "Home", "End"].includes(event.key)) return;
    event.preventDefault();
    const options = Array.from(pages.querySelectorAll('[role="option"]'));
    const index = options.indexOf(document.activeElement);
    const next = event.key === "Home" ? 0 : event.key === "End" ? options.length - 1 : (index + (event.key === "ArrowDown" ? 1 : -1) + options.length) % options.length;
    options[next]?.focus();
  });
  document.addEventListener("click", (event) => {
    if (!picker.contains(event.target)) closePicker();
  });
  picker.addEventListener("focusout", (event) => {
    if (!picker.contains(event.relatedTarget)) closePicker();
  });
  async function load() {
    const tab = selected();
    if (!tab || busy || !more) return;
    const version = generation;
    busy = true;
    retry.hidden = true;
    state.textContent = "\u6B63\u5728\u52A0\u8F7D\u2026";
    try {
      const page = await chrome.runtime.sendMessage({ type: "bua:logPage", tabId: tab.id, url: tab.url, cursor });
      if (version !== generation) return;
      if (!page || page.error) throw new Error(page?.error);
      for (const entry of page.entries) {
        const item = document.createElement("li");
        const head = document.createElement("div");
        head.className = "entry-head";
        const time = document.createElement("time");
        time.dateTime = new Date(entry.ts).toISOString();
        time.textContent = new Date(entry.ts).toLocaleString("zh-CN", { hour12: false });
        const method = document.createElement("code");
        method.className = "method";
        method.textContent = entry.method;
        const result = document.createElement("span");
        result.className = `result${entry.ok ? "" : " fail"}`;
        result.textContent = entry.ok ? "\u6210\u529F" : "\u5931\u8D25";
        head.append(time, method, result);
        item.append(head);
        if (entry.targetDescription || entry.errorCode) {
          const detail = document.createElement("p");
          detail.className = "detail";
          detail.textContent = [entry.targetDescription, entry.errorCode].filter(Boolean).join(" \xB7 ");
          item.append(detail);
        }
        list.append(item);
      }
      cursor = page.nextCursor;
      more = cursor !== null;
      state.textContent = more ? "\u5411\u4E0B\u6EDA\u52A8\u52A0\u8F7D\u66F4\u591A" : list.childElementCount ? "\u5DF2\u663E\u793A\u5F53\u524D\u9875\u9762\u7684\u5168\u90E8\u8BB0\u5F55" : "\u5F53\u524D\u9875\u9762\u6682\u65E0\u64CD\u4F5C\u8BB0\u5F55";
    } catch {
      if (version !== generation) return;
      state.textContent = "\u65E0\u6CD5\u8BFB\u53D6\u64CD\u4F5C\u65E5\u5FD7\uFF0C\u8BF7\u91CD\u8BD5\u3002";
      retry.hidden = false;
    } finally {
      if (version === generation) {
        busy = false;
        if (more && retry.hidden && state.getBoundingClientRect().top < window.innerHeight) void load();
      }
    }
  }
  function reset() {
    generation++;
    busy = false;
    cursor = null;
    more = true;
    list.textContent = "";
    updates.hidden = true;
    void load();
  }
  async function refreshTabs() {
    const previous = selectedId;
    tabs = (await chrome.tabs.query({})).filter((tab) => tab.id !== void 0 && tab.url && !tab.url.startsWith("chrome-extension://"));
    tabs.sort((a, b) => (b.lastAccessed ?? 0) - (a.lastAccessed ?? 0));
    selectedId = tabs.some((tab) => String(tab.id) === previous) ? previous : String(tabs[0]?.id ?? "");
    closePicker();
    renderPicker();
    if (!tabs.length) {
      generation++;
      list.textContent = "";
      retry.hidden = true;
      updates.hidden = true;
      state.textContent = "\u8BF7\u5148\u6253\u5F00\u9700\u8981\u67E5\u770B\u65E5\u5FD7\u7684\u9875\u9762\u3002";
      return;
    }
    reset();
  }
  retry.addEventListener("click", () => void load());
  updates.addEventListener("click", reset);
  new IntersectionObserver((entries) => {
    if (entries.some((entry) => entry.isIntersecting) && retry.hidden) void load();
  }, { rootMargin: "100px" }).observe(state);
  chrome.runtime.onMessage.addListener((msg) => {
    const tab = selected();
    if (msg.type === "bua:log" && tab && msg.entry?.tabId === tab.id && msg.entry?.url === tab.url) updates.hidden = false;
    return false;
  });
  chrome.tabs.onUpdated.addListener((id, changes) => {
    if (id === selected()?.id && changes.url) void refreshTabs();
  });
  chrome.tabs.onRemoved.addListener((id) => {
    if (tabs.some((tab) => tab.id === id)) void refreshTabs();
  });
  window.addEventListener("focus", () => void refreshTabs().catch(() => {
    state.textContent = "\u65E0\u6CD5\u8BFB\u53D6\u6807\u7B7E\u9875\uFF0C\u8BF7\u5237\u65B0\u91CD\u8BD5\u3002";
  }));
  void refreshTabs().catch(() => {
    state.textContent = "\u65E0\u6CD5\u8BFB\u53D6\u6807\u7B7E\u9875\uFF0C\u8BF7\u5237\u65B0\u91CD\u8BD5\u3002";
  });
}();
