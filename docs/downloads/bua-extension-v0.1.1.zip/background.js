// ../protocol/dist/errors.js
var BUA_ERROR_CODES = {
  /** 协议版本不匹配 —— 应对：升级扩展或桥 */
  PROTOCOL_VERSION: "BUA_PROTOCOL_VERSION",
  /** 标签不存在或已关闭 —— 应对：重新列标签 */
  TAB_NOT_FOUND: "BUA_TAB_NOT_FOUND",
  /** 标签已被其他会话接管 —— 应对：换标签或等释放 */
  TAB_CLAIMED: "BUA_TAB_CLAIMED",
  /** 句柄失效（locatorId / blobRef / snapshotId 过期） —— 应对：重新构造或重新观察 */
  HANDLE_STALE: "BUA_HANDLE_STALE",
  /**
   * chrome.debugger attach 失败（可能被 DevTools 或其他客户端占用，或企业策略拒绝）
   * —— 应对：查 capabilities 看是否已降级，走非 CDP 路径
   */
  DEBUGGER_UNAVAILABLE: "BUA_DEBUGGER_UNAVAILABLE",
  /** 导航超时 —— 应对：检查 tab.url() 后决定，不要盲目重试 */
  NAVIGATION_TIMEOUT: "BUA_NAVIGATION_TIMEOUT",
  /** 当前后端不支持该方法或该能力关闭 —— 应对：查 capabilities，走替代路径 */
  UNSUPPORTED: "BUA_UNSUPPORTED",
  /** 缺少必需的 `targetDescription` —— 应对：补上人类可读的目标描述后重试 */
  MISSING_TARGET_DESCRIPTION: "BUA_MISSING_TARGET_DESCRIPTION",
  /** 扩展侧内部错误 —— 应对：上报日志 */
  INTERNAL: "BUA_INTERNAL"
};
var ALL_BUA_ERROR_CODES = Object.values(BUA_ERROR_CODES);

// ../protocol/dist/risk.js
var ACTION_RISK_STRENGTH = Object.freeze({
  read: 0,
  write: 1,
  destructive: 2
});
var DESTRUCTIVE_METHODS = /* @__PURE__ */ new Set([
  // 目前为空 —— 见上方说明。曾经的候选及放弃理由：
  //   content.export*      → 导出用户自己看得见的内容，不是破坏
  //   cua.downloadMedia    → 触发下载，没有数据损失
  //   ax.paste             → 向页面输入文本，属 write
  //   tab.close / tabs.close → 用户可见但可撤销（标签可恢复）
]);
var READ_ONLY_METHODS = /* @__PURE__ */ new Set([
  "blob.get",
  "browser.list",
  "browser.get",
  "browser.getDefault",
  "browser.getForUrl",
  "browser.history",
  "browser.capabilities.list",
  "browser.capabilities.get",
  "user.openTabs",
  "user.getTabContext",
  "tabs.list",
  "tabs.get",
  "tabs.selected",
  "tabs.content",
  "tab.url",
  "tab.title",
  "tab.screenshot",
  "tab.getJsDialog",
  "tab.capabilities.list",
  "tab.capabilities.get",
  "playwright.domSnapshot",
  "playwright.elementInfo",
  "playwright.elementScreenshot",
  "locator.innerText",
  "locator.textContent",
  "locator.allTextContents",
  "locator.getAttribute",
  "locator.isVisible",
  "locator.isEnabled",
  "locator.count",
  "locator.evaluateAll",
  "ax.get",
  "dom_cua.get_visible_dom",
  "capabilities.list",
  "capabilities.get",
  "audit.trail",
  /*
   * `playwright.evaluate` 归为 read。
   *
   * 理由是它在本设计里**就是首选的读取机制**（对齐 Codex 的
   * `evaluate` 语义：「Evaluate JavaScript in a read-only page scope」）。
   * 它当然可以改页面，但把它标成 write 会迫使 agent 每次读值都编一句
   * targetDescription，结果是描述变成噪声、审计失去意义。
   *
   * 若部署方要更严的约束，可关闭 `capabilities.evaluate`（协议里已有该开关）。
   */
  "playwright.evaluate",
  "locator.evaluate",
  /*
   * 标签级导航归为 read。
   *
   * `tabs.new` 只是开一个标签，没有副作用落到既有页面上；`back` / `forward` /
   * `reload` 是纯导航，意图由用户或 agent 的表达已经说清。
   * 注意 `tab.goto` **不在此列** —— 它要跨到别处去，值得让 agent 说明意图。
   */
  "tabs.new",
  "tab.back",
  "tab.forward",
  "tab.reload"
]);
function classifyRisk(method) {
  if (DESTRUCTIVE_METHODS.has(method))
    return "destructive";
  if (READ_ONLY_METHODS.has(method))
    return "read";
  return "write";
}

// ../protocol/dist/shapes.js
var PROTOCOL_VERSION = "v0";
var DEFAULTS = Object.freeze({
  /** 心跳间隔。 */
  heartbeatMs: 15e3,
  /** 常规调用超时。 */
  callTimeoutMs: 3e4,
  /** 导航类长任务超时。 */
  navigationTimeoutMs: 9e4,
  /** Playwright 定位器自动等待上限。 */
  locatorTimeoutMs: 3e4,
  /** 定位器句柄无引用回收 TTL。 */
  handleTtlMs: 5 * 6e4
});

// ../protocol/dist/methods.js
var M = {
  // 握手与连接
  hello: "bua.hello",
  heartbeat: "bua.heartbeat",
  goodbye: "bua.goodbye",
  // 大对象
  blobGet: "blob.get",
  // 浏览器
  browserList: "browser.list",
  browserGet: "browser.get",
  browserGetDefault: "browser.getDefault",
  browserGetForUrl: "browser.getForUrl",
  browserNameSession: "browser.nameSession",
  browserHistory: "browser.history",
  browserCapsList: "browser.capabilities.list",
  browserCapsGet: "browser.capabilities.get",
  // 用户标签（BUA 核心差异点）
  userOpenTabs: "user.openTabs",
  userGetTabContext: "user.getTabContext",
  userClaimTab: "user.claimTab",
  // 标签集合
  tabsList: "tabs.list",
  tabsGet: "tabs.get",
  tabsNew: "tabs.new",
  tabsSelected: "tabs.selected",
  tabsContent: "tabs.content",
  tabsClose: "tabs.close",
  // 标签操作
  tabGoto: "tab.goto",
  tabBack: "tab.back",
  tabForward: "tab.forward",
  tabReload: "tab.reload",
  tabClose: "tab.close",
  tabUrl: "tab.url",
  tabTitle: "tab.title",
  tabScreenshot: "tab.screenshot",
  tabGetJsDialog: "tab.getJsDialog",
  tabMarkDeliverable: "tab.markDeliverable",
  tabMarkHandoff: "tab.markHandoff",
  tabRequestManualHandoff: "tab.requestManualHandoff",
  tabCapsList: "tab.capabilities.list",
  tabCapsGet: "tab.capabilities.get",
  // Playwright 层
  pwDomSnapshot: "playwright.domSnapshot",
  pwEvaluate: "playwright.evaluate",
  pwElementInfo: "playwright.elementInfo",
  pwElementScreenshot: "playwright.elementScreenshot",
  pwFrameLocator: "playwright.frameLocator",
  pwWaitForLoadState: "playwright.waitForLoadState",
  pwWaitForURL: "playwright.waitForURL",
  pwWaitForTimeout: "playwright.waitForTimeout",
  pwWaitForEvent: "playwright.waitForEvent",
  pwExpectNavigation: "playwright.expectNavigation",
  // Playwright 定位器构造
  locator: "playwright.locator",
  getByRole: "playwright.getByRole",
  getByText: "playwright.getByText",
  getByLabel: "playwright.getByLabel",
  getByPlaceholder: "playwright.getByPlaceholder",
  getByTestId: "playwright.getByTestId",
  // Playwright 定位器操作
  locatorClick: "locator.click",
  locatorDblclick: "locator.dblclick",
  locatorFill: "locator.fill",
  locatorType: "locator.type",
  locatorPress: "locator.press",
  locatorPressSequentially: "locator.pressSequentially",
  locatorCheck: "locator.check",
  locatorUncheck: "locator.uncheck",
  locatorSetChecked: "locator.setChecked",
  locatorSelectOption: "locator.selectOption",
  locatorInnerText: "locator.innerText",
  locatorTextContent: "locator.textContent",
  locatorAllTextContents: "locator.allTextContents",
  locatorGetAttribute: "locator.getAttribute",
  locatorIsVisible: "locator.isVisible",
  locatorIsEnabled: "locator.isEnabled",
  locatorCount: "locator.count",
  locatorWaitFor: "locator.waitFor",
  locatorEvaluate: "locator.evaluate",
  locatorEvaluateAll: "locator.evaluateAll",
  locatorDownloadMedia: "locator.downloadMedia",
  // 定位器组合（句柄模型下这些都是句柄 → 句柄）
  locatorFilter: "locator.filter",
  locatorLocator: "locator.locator",
  locatorFirst: "locator.first",
  locatorLast: "locator.last",
  locatorNth: "locator.nth",
  locatorAnd: "locator.and",
  locatorOr: "locator.or",
  locatorAll: "locator.all",
  /** 显式释放句柄。句柄另有 TTL 自动回收。 */
  locatorRelease: "locator.release",
  // AX 层
  axGet: "ax.get",
  axWrite: "ax.write",
  axClick: "ax.click",
  axTypeText: "ax.typeText",
  axPressKey: "ax.pressKey",
  axSetValue: "ax.setValue",
  axPaste: "ax.paste",
  axSelectText: "ax.selectText",
  axScroll: "ax.scroll",
  axDrag: "ax.drag",
  axPerformSecondaryAction: "ax.performSecondaryAction",
  // CUA 层（视口坐标）
  cuaClick: "cua.click",
  cuaDoubleClick: "cua.double_click",
  cuaMove: "cua.move",
  cuaDrag: "cua.drag",
  cuaScroll: "cua.scroll",
  cuaType: "cua.type",
  cuaKeypress: "cua.keypress",
  cuaDownloadMedia: "cua.downloadMedia",
  // DomCUA 层（可见 DOM 节点 id）
  domCuaGetVisibleDom: "dom_cua.get_visible_dom",
  domCuaClick: "dom_cua.click",
  domCuaDoubleClick: "dom_cua.double_click",
  domCuaScroll: "dom_cua.scroll",
  domCuaType: "dom_cua.type",
  domCuaKeypress: "dom_cua.keypress",
  domCuaDownloadMedia: "dom_cua.downloadMedia",
  // 内容导出
  contentExport: "content.export",
  contentExportGsuite: "content.exportGsuite",
  contentExportYouTubeTranscript: "content.exportYouTubeTranscript",
  // 能力
  capsList: "capabilities.list",
  capsGet: "capabilities.get",
  // 审计（BUA 增补）
  auditTrail: "audit.trail",
  auditUndo: "audit.undo"
};
var ALL_METHODS = Object.values(M);
var MUTATING_METHODS = /* @__PURE__ */ new Set([
  M.tabsNew,
  M.tabsClose,
  M.userClaimTab,
  M.tabGoto,
  M.tabBack,
  M.tabForward,
  M.tabReload,
  M.tabClose,
  M.tabMarkDeliverable,
  M.tabMarkHandoff,
  M.tabRequestManualHandoff,
  M.locatorClick,
  M.locatorDblclick,
  M.locatorFill,
  M.locatorType,
  M.locatorPress,
  M.locatorPressSequentially,
  M.locatorCheck,
  M.locatorUncheck,
  M.locatorSetChecked,
  M.locatorSelectOption,
  M.axClick,
  M.axTypeText,
  M.axPressKey,
  M.axSetValue,
  M.axPaste,
  M.axSelectText,
  M.axScroll,
  M.axDrag,
  M.axPerformSecondaryAction,
  M.cuaClick,
  M.cuaDoubleClick,
  M.cuaMove,
  M.cuaDrag,
  M.cuaScroll,
  M.cuaType,
  M.cuaKeypress,
  M.domCuaClick,
  M.domCuaDoubleClick,
  M.domCuaScroll,
  M.domCuaType,
  M.domCuaKeypress,
  M.auditUndo
]);

// src/background.ts
var LOG_KEY = "activityLog";
var CONSENT_KEY = "onboardingAcceptedAt";
var MAX_LOG = 200;
var CONNECTION_ALARM = "bua:connection-watchdog";
var BRIDGE_PORT = 17432;
var ws = null;
var reconnectTimer = null;
var attachedTabs = /* @__PURE__ */ new Set();
var tabSessions = /* @__PURE__ */ new Map();
var debugGroups = /* @__PURE__ */ new Map();
async function markDebugging(tabId) {
  await chrome.action.setBadgeText({ tabId, text: "DBG" });
  await chrome.action.setBadgeBackgroundColor({ tabId, color: "#2563eb" });
  await chrome.action.setTitle({ tabId, title: "BUA \xB7 \u6B63\u5728\u8C03\u8BD5\u6B64\u6807\u7B7E\u9875" });
  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab.groupId !== -1 || tab.pinned) return;
    const groupId = await chrome.tabs.group({ tabIds: tabId });
    debugGroups.set(tabId, groupId);
    await chrome.tabGroups.update(groupId, { title: "BUA \xB7 \u6B63\u5728\u8C03\u8BD5", color: "blue", collapsed: false });
  } catch (error) {
    console.warn("[bua] \u6807\u7B7E\u7EC4\u6807\u8BC6\u5931\u8D25", error);
  }
}
async function clearDebugging(tabId) {
  tabSessions.delete(tabId);
  const groupId = debugGroups.get(tabId);
  debugGroups.delete(tabId);
  try {
    const tab = await chrome.tabs.get(tabId);
    if (groupId !== void 0 && tab.groupId === groupId) await chrome.tabs.ungroup(tabId);
    await chrome.action.setBadgeText({ tabId, text: "" });
    await chrome.action.setTitle({ tabId, title: "BUA \u2014 \u8BBE\u7F6E" });
  } catch {
  }
}
var currentCapabilities = {
  cdp: false,
  screenshots: false,
  fileUploads: false,
  downloads: false,
  evaluate: false,
  management: false,
  notes: ["\u5C1A\u672A\u63A2\u6D4B\u3002"]
};
var capabilitiesProbed = false;
async function detectCapabilities() {
  if (capabilitiesProbed) return;
  const tabs = await chrome.tabs.query({});
  const candidates = tabs.filter((tab2) => /^https?:\/\//.test(tab2.url ?? "") && !/^https?:\/\/(chromewebstore\.google\.com|chrome\.google\.com\/webstore)(\/|$)/.test(tab2.url ?? ""));
  const tab = candidates.find((candidate) => candidate.active) ?? candidates[0];
  const probeTabId = tab?.id;
  if (probeTabId === void 0) {
    currentCapabilities = {
      ...currentCapabilities,
      notes: []
    };
    return;
  }
  try {
    await chrome.debugger.attach({ tabId: probeTabId }, "1.3");
    currentCapabilities = {
      cdp: true,
      screenshots: true,
      fileUploads: true,
      downloads: true,
      evaluate: true,
      management: true,
      notes: []
    };
    capabilitiesProbed = true;
    await chrome.debugger.detach({ tabId: probeTabId }).catch(() => {
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    const byPolicy = /restricted by policy/i.test(message);
    if (!byPolicy) {
      currentCapabilities = { ...currentCapabilities, notes: [] };
      return;
    }
    currentCapabilities = {
      cdp: false,
      screenshots: !/Screenshot capture is restricted by policy/i.test(message),
      fileUploads: false,
      downloads: false,
      evaluate: false,
      management: true,
      // chrome.tabs / bookmarks 等不受 CDP 策略影响
      notes: [
        "\u26A0 \u4F01\u4E1A\u7B56\u7565\u9650\u5236\u4E86 CDP \u6D4F\u89C8\u5668\u64CD\u4F5C",
        "\u771F\u5B9E\u8F93\u5165\u4E8B\u4EF6\u3001\u622A\u56FE\u4E0E\u8DE8 iframe \u4E00\u81F4\u63A7\u5236\u4E0D\u53EF\u7528"
      ]
    };
    capabilitiesProbed = true;
  }
  send({
    jsonrpc: "2.0",
    method: "bua.event",
    params: {
      type: "backend.ready",
      chromeVersion: detectChromeVersion(),
      capabilities: currentCapabilities
    }
  });
}
function detectChromeVersion() {
  if (typeof navigator === "undefined") return null;
  return /\bChrome\/([\d.]+)/.exec(navigator.userAgent)?.[1] ?? null;
}
async function getLog() {
  const bag = await chrome.storage.local.get(LOG_KEY);
  const value = bag[LOG_KEY];
  return Array.isArray(value) ? value : [];
}
async function appendLog(entry) {
  const log = await getLog();
  log.unshift({ ...entry, id: crypto.randomUUID() });
  await chrome.storage.local.set({ [LOG_KEY]: log.slice(0, MAX_LOG) });
  try {
    await chrome.runtime.sendMessage({ type: "bua:log", entry });
  } catch {
  }
}
async function attachTab(tabId) {
  if (attachedTabs.has(tabId)) return { ok: true };
  try {
    await chrome.debugger.attach({ tabId }, "1.3");
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    if (/restricted by policy/i.test(message)) {
      return { ok: false, reason: `\u4F01\u4E1A\u7B56\u7565\u62D2\u7EDD\u4E86 CDP\uFF1A${message}` };
    }
    return { ok: false, reason: message };
  }
  attachedTabs.add(tabId);
  if (!capabilitiesProbed) {
    currentCapabilities = { cdp: true, screenshots: true, fileUploads: true, downloads: true, evaluate: true, management: true, notes: [] };
    capabilitiesProbed = true;
    send({ jsonrpc: "2.0", method: "bua.event", params: { type: "backend.ready", chromeVersion: detectChromeVersion(), capabilities: currentCapabilities } });
  }
  await chrome.debugger.sendCommand({ tabId }, "Page.enable").catch(() => {
  });
  await chrome.debugger.sendCommand({ tabId }, "Runtime.enable").catch(() => {
  });
  await markDebugging(tabId);
  return { ok: true };
}
async function detachTab(tabId) {
  if (!attachedTabs.has(tabId)) {
    tabSessions.delete(tabId);
    return;
  }
  attachedTabs.delete(tabId);
  await clearDebugging(tabId);
  try {
    await chrome.debugger.detach({ tabId });
  } catch {
  }
}
chrome.debugger.onDetach.addListener((source, reason) => {
  const tabId = source.tabId;
  if (typeof tabId !== "number") return;
  attachedTabs.delete(tabId);
  void clearDebugging(tabId);
  send({
    jsonrpc: "2.0",
    method: "bua.event",
    params: { type: "debugger.detached", tabId, reason }
  });
});
function send(msg) {
  if (ws !== null && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(msg));
}
async function connect() {
  if (ws !== null && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
    return;
  }
  const accepted = await isConsentGiven();
  if (!accepted) return;
  if (ws !== null && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return;
  const port = BRIDGE_PORT;
  const socket = new WebSocket(`ws://127.0.0.1:${port}`);
  ws = socket;
  let keepaliveTimer = null;
  socket.addEventListener("open", () => {
    keepaliveTimer = setInterval(() => {
      if (socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ jsonrpc: "2.0", method: M.heartbeat, params: {} }));
      }
    }, 2e4);
    retryDelayMs = 2e3;
    send({
      jsonrpc: "2.0",
      id: 0,
      method: M.hello,
      params: {
        protocolVersion: PROTOCOL_VERSION,
        role: "extension",
        client: {
          extensionId: chrome.runtime.id,
          extensionVersion: chrome.runtime.getManifest().version,
          ...detectChromeVersion() !== null ? { chromeVersion: detectChromeVersion() } : {}
        },
        capabilities: ["cdp", "screenshots", "downloads", "evaluate", "management"]
      }
    });
    void detectCapabilities();
  });
  socket.addEventListener("message", (ev) => {
    let msg;
    try {
      msg = JSON.parse(String(ev.data));
    } catch {
      return;
    }
    void handleBridgeMessage(msg);
  });
  socket.addEventListener("close", (event) => {
    if (keepaliveTimer !== null) clearInterval(keepaliveTimer);
    console.warn("BUA \u6865\u8FDE\u63A5\u5173\u95ED", { code: event.code, reason: event.reason, wasClean: event.wasClean });
    if (ws !== socket) return;
    void Promise.all([...attachedTabs].map(detachTab));
    ws = null;
    scheduleReconnect();
  });
  socket.addEventListener("error", () => {
  });
}
var retryDelayMs = 2e3;
var RETRY_MAX_MS = 3e4;
function scheduleReconnect() {
  if (reconnectTimer !== null) return;
  void isConsentGiven().then((accepted) => {
    if (!accepted) return;
    reconnectTimer = setTimeout(() => {
      reconnectTimer = null;
      void connect();
    }, retryDelayMs);
    retryDelayMs = Math.min(RETRY_MAX_MS, retryDelayMs * 2);
  });
}
function methodToCdp(method, params) {
  switch (method) {
    // ── 标签导航与信息 ──
    case M.tabGoto:
      return [{ method: "Page.navigate", params: { url: String(params["url"] ?? "") } }];
    case M.tabReload:
      return [{ method: "Page.reload", params: {} }];
    case M.tabUrl:
      return [{ method: "Runtime.evaluate", params: {
        expression: "location.href",
        returnByValue: true
      } }];
    case M.tabTitle:
      return [{ method: "Runtime.evaluate", params: {
        expression: "document.title",
        returnByValue: true
      } }];
    case M.tabScreenshot:
      return [{ method: "Page.captureScreenshot", params: {
        format: params["format"] ?? "png",
        ...params["quality"] !== void 0 ? { quality: params["quality"] } : {},
        captureBeyondViewport: params["fullPage"] === true
      } }];
    case M.tabBack:
      return [{ method: "Runtime.evaluate", params: { expression: "history.back()", returnByValue: true } }];
    case M.tabForward:
      return [{ method: "Runtime.evaluate", params: { expression: "history.forward()", returnByValue: true } }];
    // ── Playwright 层 ──
    case M.pwDomSnapshot:
      return [{ method: "Runtime.evaluate", params: { expression: DOM_SNAPSHOT_EXPR, returnByValue: true } }];
    case M.pwEvaluate:
      return [{ method: "Runtime.evaluate", params: {
        expression: String(params["functionSource"] ?? "undefined"),
        returnByValue: true,
        awaitPromise: true
      } }];
    case M.locatorClick:
    case M.locatorFill:
    case M.locatorInnerText:
    case M.locatorTextContent:
    case M.locatorIsVisible:
    case M.locatorIsEnabled:
    case M.locatorCount:
      return [{ method: "Runtime.evaluate", params: {
        expression: buildLocatorExpression(method, params),
        returnByValue: true,
        awaitPromise: true
      } }];
    // ── AX 层 ──
    case M.axGet:
      return [{ method: "Runtime.evaluate", params: { expression: AX_STATE_EXPR, returnByValue: true } }];
    case M.axClick:
      return [{ method: "Runtime.evaluate", params: {
        expression: `document.elementFromPoint(${Number(params["x"] ?? 0)}, ${Number(params["y"] ?? 0)})?.click(); true`,
        returnByValue: true
      } }];
    // ── CUA 坐标层：真实输入事件（这是 scripting 做不到的，也是保留 debugger 的理由）──
    case M.cuaClick:
      return [
        { method: "Input.dispatchMouseEvent", params: {
          type: "mousePressed",
          x: Number(params["x"] ?? 0),
          y: Number(params["y"] ?? 0),
          button: params["button"] ?? "left",
          clickCount: 1
        } },
        { method: "Input.dispatchMouseEvent", params: {
          type: "mouseReleased",
          x: Number(params["x"] ?? 0),
          y: Number(params["y"] ?? 0),
          button: params["button"] ?? "left",
          clickCount: 1
        } }
      ];
    case M.cuaDoubleClick:
      return [
        { method: "Input.dispatchMouseEvent", params: {
          type: "mousePressed",
          x: Number(params["x"] ?? 0),
          y: Number(params["y"] ?? 0),
          button: "left",
          clickCount: 2
        } },
        { method: "Input.dispatchMouseEvent", params: {
          type: "mouseReleased",
          x: Number(params["x"] ?? 0),
          y: Number(params["y"] ?? 0),
          button: "left",
          clickCount: 2
        } }
      ];
    case M.cuaMove:
      return [{ method: "Input.dispatchMouseEvent", params: {
        type: "mouseMoved",
        x: Number(params["x"] ?? 0),
        y: Number(params["y"] ?? 0)
      } }];
    case M.cuaScroll:
      return [{ method: "Input.dispatchMouseEvent", params: {
        type: "mouseWheel",
        x: Number(params["x"] ?? 0),
        y: Number(params["y"] ?? 0),
        deltaX: Number(params["deltaX"] ?? 0),
        deltaY: Number(params["deltaY"] ?? 0)
      } }];
    case M.cuaType:
      return [{ method: "Input.insertText", params: { text: String(params["text"] ?? "") } }];
    case M.cuaKeypress:
      return [
        { method: "Input.dispatchKeyEvent", params: { type: "keyDown", key: String(params["key"] ?? "") } },
        { method: "Input.dispatchKeyEvent", params: { type: "keyUp", key: String(params["key"] ?? "") } }
      ];
    default:
      return null;
  }
}
function buildLocatorExpression(method, params) {
  const selector = String(params["selector"] ?? "");
  const safeSelector = JSON.stringify(selector);
  switch (method) {
    case M.locatorClick:
      return `(() => { const el = document.querySelector(${safeSelector}); if (!el) return { ok: false, error: 'not found' }; el.click(); return { ok: true }; })()`;
    case M.locatorFill:
      return `(() => { const el = document.querySelector(${safeSelector}); if (!el) return { ok: false, error: 'not found' }; const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set; setter?.call(el, ${JSON.stringify(String(params["value"] ?? ""))}); el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); return { ok: true }; })()`;
    case M.locatorInnerText:
      return `document.querySelector(${safeSelector})?.innerText ?? null`;
    case M.locatorTextContent:
      return `document.querySelector(${safeSelector})?.textContent ?? null`;
    case M.locatorIsVisible:
      return `(() => { const el = document.querySelector(${safeSelector}); if (!el) return false; const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; })()`;
    case M.locatorIsEnabled:
      return `(() => { const el = document.querySelector(${safeSelector}); return el ? !el.disabled : false; })()`;
    case M.locatorCount:
      return `document.querySelectorAll(${safeSelector}).length`;
    default:
      return "null";
  }
}
var DOM_SNAPSHOT_EXPR = `(() => {
  const out = [];
  const sel = 'a[href],button,input,select,textarea,[role],[onclick],[contenteditable="true"]';
  let i = 0;
  for (const el of document.querySelectorAll(sel)) {
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) continue;
    if (i >= 400) break;
    out.push({
      id: i++,
      tag: el.tagName.toLowerCase(),
      role: el.getAttribute('role') || undefined,
      name: (el.getAttribute('aria-label') || el.innerText || el.value || '').trim().slice(0, 120),
      selector: el.id ? '#' + CSS.escape(el.id) : undefined,
      rect: { x: Math.round(r.x), y: Math.round(r.y), width: Math.round(r.width), height: Math.round(r.height) },
    });
  }
  return out;
})()`;
var AX_STATE_EXPR = `(() => {
  const lines = [];
  const sel = '[role],a[href],button,input,select,textarea,h1,h2,h3';
  let i = 0;
  for (const el of document.querySelectorAll(sel)) {
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) continue;
    if (i >= 300) break;
    const role = el.getAttribute('role') || el.tagName.toLowerCase();
    const name = (el.getAttribute('aria-label') || el.innerText || el.value || '').trim().slice(0, 80);
    const state = [];
    if (el.disabled) state.push('disabled');
    if (el.checked) state.push('checked');
    lines.push('[' + i++ + '] ' + role + (name ? ' "' + name + '"' : '') + (state.length ? ' (' + state.join(',') + ')' : ''));
  }
  return lines.join('\\n');
})()`;
async function handleBridgeMessage(raw) {
  if (typeof raw !== "object" || raw === null) return;
  const msg = raw;
  const id = msg["id"];
  const method = msg["method"];
  if (method === "bua.event") {
    const event = msg["params"];
    if (event?.type === "session.closed" && event.sessionId) {
      for (const [tabId2, owners] of tabSessions) {
        owners.delete(event.sessionId);
        if (owners.size === 0) await detachTab(tabId2);
      }
    }
    return;
  }
  if (typeof method !== "string" || id === void 0) return;
  const params = typeof msg["params"] === "object" && msg["params"] !== null ? msg["params"] : {};
  const sessionId = typeof params["__buaSessionId"] === "string" ? params["__buaSessionId"] : void 0;
  const risk = classifyRisk(method);
  const targetDescription = typeof params["targetDescription"] === "string" ? params["targetDescription"] : void 0;
  let logTabId = typeof params["tabId"] === "number" ? params["tabId"] : void 0;
  let logUrl;
  async function capturePage(tabId2) {
    logTabId = tabId2;
    logUrl = (await chrome.tabs.get(tabId2).catch(() => void 0))?.url;
  }
  if (logTabId !== void 0) await capturePage(logTabId);
  const respond = async (result, errorCode, message) => {
    await appendLog({
      ts: Date.now(),
      ...logTabId !== void 0 ? { tabId: logTabId } : {},
      ...logUrl !== void 0 ? { url: logUrl } : {},
      method,
      risk,
      ok: errorCode === void 0,
      ...targetDescription !== void 0 ? { targetDescription } : {},
      ...errorCode !== void 0 ? { errorCode } : {},
      ...sessionId !== void 0 ? { sessionId } : {}
    });
    send(
      errorCode === void 0 ? { jsonrpc: "2.0", id, result } : { jsonrpc: "2.0", id, error: { code: -32e3, message: message ?? errorCode, data: { buaCode: errorCode } } }
    );
  };
  if (method === M.heartbeat) {
    send({ jsonrpc: "2.0", id, result: { ok: true } });
    return;
  }
  switch (method) {
    case M.userOpenTabs:
    case M.tabsList: {
      const tabs = await chrome.tabs.query({});
      await respond({
        tabs: tabs.map((t) => ({
          id: t.id,
          url: t.url,
          title: t.title,
          active: t.active === true,
          pinned: t.pinned === true,
          windowId: t.windowId,
          status: t.status,
          ...method === M.userOpenTabs ? {
            audible: t.audible === true,
            claimed: (tabSessions.get(t.id)?.size ?? 0) > 0,
            claimedBy: tabSessions.get(t.id)?.values().next().value
          } : {}
        }))
      });
      return;
    }
    case M.userGetTabContext:
    case M.userClaimTab: {
      const target = params["tabId"];
      if (typeof target !== "number") {
        await respond(null, BUA_ERROR_CODES.TAB_NOT_FOUND, "\u9700\u8981\u660E\u786E\u7684 tabId");
        return;
      }
      let tab;
      try {
        tab = await chrome.tabs.get(target);
      } catch {
        await respond(null, BUA_ERROR_CODES.TAB_NOT_FOUND, "\u6807\u7B7E\u5DF2\u5173\u95ED\uFF0C\u8BF7\u91CD\u65B0\u5217\u51FA\u6807\u7B7E");
        return;
      }
      if (method === M.userGetTabContext) {
        await respond({ context: { title: tab.title, url: tab.url } });
        return;
      }
      const owners = tabSessions.get(target) ?? /* @__PURE__ */ new Set();
      if (!sessionId || [...owners].some((owner) => owner !== sessionId)) {
        await respond(null, BUA_ERROR_CODES.TAB_CLAIMED, "\u6807\u7B7E\u5DF2\u88AB\u5176\u4ED6\u4F1A\u8BDD\u4F7F\u7528\uFF0C\u6216\u8BF7\u6C42\u7F3A\u5C11\u4F1A\u8BDD\u8EAB\u4EFD");
        return;
      }
      owners.add(sessionId);
      tabSessions.set(target, owners);
      await respond({ tabId: target });
      return;
    }
    case M.tabsNew: {
      const url = typeof params["url"] === "string" ? params["url"] : void 0;
      const tab = await chrome.tabs.create({
        ...url !== void 0 ? { url } : {},
        active: params["visible"] === true
      });
      logTabId = tab.id;
      logUrl = tab.url ?? url;
      await respond({ tabId: tab.id, url: tab.url, title: tab.title });
      return;
    }
    case M.tabsSelected: {
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      logTabId = tab?.id;
      logUrl = tab?.url;
      await respond(tab === void 0 ? { tab: null } : { tab: { id: tab.id, url: tab.url, title: tab.title } });
      return;
    }
    case M.tabClose:
    case M.tabsClose: {
      const target = typeof params["tabId"] === "number" ? params["tabId"] : void 0;
      if (target === void 0) {
        await respond(null, BUA_ERROR_CODES.UNSUPPORTED, "\u5173\u95ED\u6807\u7B7E\u9700\u8981 tabId");
        return;
      }
      await detachTab(target);
      await chrome.tabs.remove(target);
      await respond({ ok: true });
      return;
    }
    case M.browserGetDefault:
    case M.browserList: {
      const manifest = chrome.runtime.getManifest();
      await respond({
        browsers: [
          {
            id: "extension",
            name: "\u672C\u673A Chrome",
            family: "chrome",
            type: "extension",
            tabs: (await chrome.tabs.query({})).map((t) => ({ id: t.id, url: t.url, title: t.title })),
            metadata: { extensionInstanceId: chrome.runtime.id }
          }
        ],
        capabilities: currentCapabilities,
        version: manifest.version
      });
      return;
    }
    default:
      break;
  }
  let tabId = typeof params["tabId"] === "number" ? params["tabId"] : void 0;
  if (tabId === void 0) {
    const [active] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (active?.id !== void 0) {
      tabId = active.id;
    }
  }
  if (tabId === void 0) {
    await respond(null, BUA_ERROR_CODES.TAB_NOT_FOUND, `\u65B9\u6CD5 ${method} \u9700\u8981 tabId\uFF0C\u4E14\u5F53\u524D\u6CA1\u6709\u6D3B\u52A8\u6807\u7B7E`);
    return;
  }
  await capturePage(tabId);
  const attach = await attachTab(tabId);
  if (!attach.ok) {
    await respond(null, BUA_ERROR_CODES.DEBUGGER_UNAVAILABLE, attach.reason);
    return;
  }
  if (sessionId) {
    const owners = tabSessions.get(tabId) ?? /* @__PURE__ */ new Set();
    owners.add(sessionId);
    tabSessions.set(tabId, owners);
  }
  const cdpCalls = methodToCdp(method, params);
  if (cdpCalls === null) {
    await respond(null, BUA_ERROR_CODES.UNSUPPORTED, `\u65B9\u6CD5 ${method} \u5C1A\u672A\u5B9E\u73B0`);
    return;
  }
  try {
    let last = null;
    for (const call of cdpCalls) {
      last = await chrome.debugger.sendCommand({ tabId }, call.method, call.params);
    }
    await respond(last);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    await respond(null, BUA_ERROR_CODES.INTERNAL, message);
  }
}
async function isConsentGiven() {
  const bag = await chrome.storage.local.get(CONSENT_KEY);
  return typeof bag[CONSENT_KEY] === "number";
}
async function syncConnectionAlarm() {
  if (await isConsentGiven()) {
    await chrome.alarms.create(CONNECTION_ALARM, { periodInMinutes: 0.5 });
  } else {
    await chrome.alarms.clear(CONNECTION_ALARM);
  }
}
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== CONNECTION_ALARM) return;
  void connect();
});
void syncConnectionAlarm();
chrome.action.onClicked.addListener(() => {
  void chrome.runtime.openOptionsPage();
});
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    void chrome.runtime.openOptionsPage();
  }
  void connect();
});
chrome.runtime.onStartup.addListener(() => {
  void connect();
});
void connect();
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (CONSENT_KEY in changes) {
    void syncConnectionAlarm();
    if (reconnectTimer !== null) clearTimeout(reconnectTimer);
    reconnectTimer = null;
    retryDelayMs = 2e3;
    ws?.close();
    ws = null;
    void connect();
  }
});
chrome.tabs.onRemoved.addListener((tabId) => {
  attachedTabs.delete(tabId);
  void clearDebugging(tabId);
});
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (typeof msg !== "object" || msg === null) return false;
  const type = msg["type"];
  if (type === "bua:status") {
    void (async () => {
      sendResponse({
        connected: ws !== null && ws.readyState === WebSocket.OPEN,
        port: BRIDGE_PORT,
        consentGiven: await isConsentGiven(),
        attachedTabs: [...attachedTabs],
        capabilities: currentCapabilities
      });
    })();
    return true;
  }
  if (type === "bua:logPage") {
    void (async () => {
      const log = typeof msg.tabId === "number" && typeof msg.url === "string" ? (await getLog()).filter((entry) => entry.tabId === msg.tabId && entry.url === msg.url) : [];
      const cursor = typeof msg.cursor === "string" ? msg.cursor : null;
      const key = (entry) => entry.id ?? JSON.stringify(entry);
      const start = cursor === null ? 0 : log.findIndex((entry) => key(entry) === cursor) + 1;
      const entries = cursor !== null && start === 0 ? [] : log.slice(start, start + 20);
      const hasMore = entries.length > 0 && start + entries.length < log.length;
      sendResponse({ entries, nextCursor: hasMore ? key(entries[entries.length - 1]) : null });
    })().catch(() => sendResponse({ error: "\u65E0\u6CD5\u8BFB\u53D6\u64CD\u4F5C\u8BB0\u5F55" }));
    return true;
  }
  if (type === "bua:setCapabilities") {
    const caps = msg["capabilities"];
    if (typeof caps === "object" && caps !== null) {
      currentCapabilities = caps;
    }
    return false;
  }
  if (type === "bua:reconnect") {
    retryDelayMs = 2e3;
    ws?.close();
    ws = null;
    void connect().then(async () => {
      await new Promise((r) => setTimeout(r, 350));
      sendResponse({
        connected: ws !== null && ws.readyState === WebSocket.OPEN,
        port: BRIDGE_PORT
      });
    });
    return true;
  }
  return false;
});
